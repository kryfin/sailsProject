# sailsAdmin1

a [Sails](http://sailsjs.org) application
