/**
 * EmployeeController
 *
 * @description :: Server-side logic for managing Employees
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
create: function(req, res, next) {

    var params = req.params.all();

    Employee.create(params, function(err, employee) {

        if (err) return next(err);

        res.status(201);

        res.json(employee);

    });
},


   update: function (req, res, next) {

        var criteria = {};

        criteria = _.merge({}, req.params.all(), req.body);

        var id = req.param('id');


        if (!id) {
            return res.badRequest('No id provided.');
        }

        Employee.update(id, criteria, function (err, employee) {

            if(employee.length === 0) return res.notFound();

            if (err) return next(err);

            res.json(employee);

        });
    },


  destroy: function (req, res, next) {

        var id = req.param('id');

        if (!id) {
            return res.badRequest('No id provided.');
        }

        Employee.findOne(id).done(function(err, result) {
            if (err) return res.serverError(err);

            if (!result) return res.notFound();

            Employee.destroy(id, function (err) {

                if (err) return next (err);

                return res.json(result);
            });

        });
    },

};

